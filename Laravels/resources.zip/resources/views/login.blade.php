<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - ARK</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body>
    
    <div class="auth-wrapper">
        <div class="auth-box">
            <img src="{{ asset('imagens/logo_ark.png') }}" class="logo">
            <h2>Login</h2>
            <form action="{{ route('home') }}">
                <input type="text" placeholder="Usuário" required>
                <input type="password" placeholder="Senha" required>
                <button type="submit" class="btn-auth">Realizar Login</button>
            </form>
            <p>Novo por aqui? <a href="{{ route('cadastro') }}">Cadastre-se</a></p>
        </div>
    </div>
</body>
</html>