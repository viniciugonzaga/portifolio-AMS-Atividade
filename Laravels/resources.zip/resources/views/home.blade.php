<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>RPG ARK - Home</title>
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
    <link rel="icon" type="image/png" href="{{ asset('imagens/logo_ark.png') }}">
</head>
<body>
    <div class="animated-bg"></div>
    <nav class="navbar">
        <div class="logo-group">
    <img src="{{ asset('imagens/logo_ark.png') }}" alt="Ícone ARK" class="logo-icon">
    
    <img src="{{ asset('imagens/fonte_ark.png') }}" alt="RPG ARK" class="logo-estampa">
</div>
       <div class="nav-links">
           <a href="{{ route('login') }}" class="nav-btn-login">Login</a>
           <a href="{{ route('cadastro') }}" class="nav-item-cadastro">Cadastro</a>
         </div>
    </nav>

    <main class="hero">
        <div class="glass-card">
            <h1>Sua Jornada Começa Aqui</h1>
            <p>Explore o sistema ARK e evolua seu personagem no maior RPG da escola.</p>
            <a href="{{ route('cadastro') }}" class="cta-button">Começar Agora</a>
        </div>
    </main>
</body>
</html>