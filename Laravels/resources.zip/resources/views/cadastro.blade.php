<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - ARK</title>
    <link rel="stylesheet" href="{{ asset('css/cadastro.css') }}">
</head>
<body>
    
    <div class="auth-wrapper">
        <div class="auth-box">
            <img src="{{ asset('imagens/logo_ark.png') }}" class="logo">
            <h2>Criar Conta</h2>
            <form action="{{ route('login') }}">
                <input type="text" placeholder="Nome de Jogador" required>
                <input type="email" placeholder="E-mail" required>
                <input type="password" placeholder="Senha" required>
                <button type="submit" class="btn-auth">Finalizar Cadastro</button>
            </form>
            <a href="{{ route('login') }}" class="back-link">Voltar para Login</a>
        </div>
    </div>
</body>
</html>